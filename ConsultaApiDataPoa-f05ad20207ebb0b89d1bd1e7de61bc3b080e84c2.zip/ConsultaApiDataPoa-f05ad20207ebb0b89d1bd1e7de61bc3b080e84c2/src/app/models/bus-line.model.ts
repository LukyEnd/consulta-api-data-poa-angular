export interface ApiBusLine {
  id: number;
  codigo: string;
  nome: string;
}
