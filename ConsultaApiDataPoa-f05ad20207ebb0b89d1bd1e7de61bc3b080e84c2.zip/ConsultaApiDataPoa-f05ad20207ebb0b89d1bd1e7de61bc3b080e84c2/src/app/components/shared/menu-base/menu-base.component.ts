import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-base',
  templateUrl: './menu-base.component.html',
  styleUrls: ['./menu-base.component.scss'],
})
export class MenuBaseComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
